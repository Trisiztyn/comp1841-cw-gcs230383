<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="admin_dashboard">
        <h1>Admin Home</h1>
        <h2>Manage</h2>
        <ul>
            <li><a href="manage_posts.php"> Posts</a></li>
            <li><a href="manage_users.php"> Users</a></li>
            <li><a href="manage_modules.php"> Modules</a></li>
        </ul>
        <a href="logout.php" class="home-button">Logout</a>
    </div>


</body>
</html>
