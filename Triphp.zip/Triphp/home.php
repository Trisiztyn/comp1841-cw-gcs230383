<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

$user = $_SESSION['user'];

// Fetch all posts from the database


$stmt = $pdo->query("SELECT posts.id, posts.title, posts.created_at, posts.updated_at, posts.user_id, users.name AS name 
                     FROM posts 
                     JOIN users ON posts.user_id = users.id 
                     ORDER BY posts.created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="background">
<div class="home_container">
    <div class="welcome">
        <h1> Greetings, <?php echo htmlspecialchars($user['name']); ?>! so happy to have you!</h1>
        <p class="description">Just another QandA platform, good luck using it.</p>
        <p> Your Account: <?php echo htmlspecialchars($user['email']); ?></p>

        <a href="logout.php" class="home-button">Logout</a>
        <a href="create_post.php" class="home-button">Create post</a>
        <a href="edit_profile.php" class="home-button">Edit profile</a>
        <a href="admin_help.php" class="home-button">Admin Help</a>
        <div class="posts">
    <h2>All Posts</h2>
    <?php foreach ($posts as $post): ?>
        <div class="post" id="post-<?php echo $post['id']; ?>">
            <h3><a href="view_post.php?post_id=<?php echo $post['id']; ?>">
                <?php echo htmlspecialchars($post['title']); ?>
            </a></h3>
            <p>By: <?php echo htmlspecialchars($post['name']); ?></p>
            <p>Date: <?php echo date("d/m/Y, H:i", strtotime($post['created_at'])); ?></p>
            <?php if (!empty($post['updated_at'])): ?>
                <p>Updated on: <?php echo date("d/m/Y, H:i", strtotime($post['updated_at'])); ?></p>
            <?php endif; ?>

            <!-- Check if the logged-in user is the creator of the post -->
            <?php if ($user['id'] === $post['user_id']): ?>
                <a href="edit_post.php?post_id=<?php echo $post['id']; ?>" class="home-button">Edit</a>
                <a href="delete_post.php?post_id=<?php echo $post['id']; ?>" class="home-button"
                   onclick="return confirm('Delete this post?');">Erase</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

</div>

    </div>
</div>

</body>
</html>
