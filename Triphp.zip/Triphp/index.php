<?php
session_start();
if (isset($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register & Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <div class="background">
       
        <div class="profile-check" id="signIn">
            <h1 class="form-title">Sign In</h1>
            <?php
            if (isset($errors['login'])) {
                echo '<div class="error-main">
                            <p>' . $errors['login'] . '</p>
                          </div>';
                unset($errors['login']);
            }
            ?>
            <form method="POST" action="user-account.php">
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                    <?php
                    if (isset($errors['email'])) {
                        echo ' <div class="error">
                                <p>' . $errors['email'] . '</p>
                              </div>';
                    }
                    ?>
                </div>
                <div class="input-group password">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                    <i id="eye" class="fa fa-eye"></i>
                    <?php
                    if (isset($errors['password'])) {
                        echo ' <div class="error">
                                <p>' . $errors['password'] . '</p>
                              </div>';
                    }
                    ?>
                </div>
              
                <input type="submit" class="btn" value="Sign In" name="signin">
            </form>
            <p class="or">
                           Or
            </p>

            <div class="admin-login">
            <a href="admin_login.php" class="button">Admin Login</a>

            <div class="contact-admin">
            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=tritranpham@gmail.com&su=I%20need%20some%20help%20from%20admin" target="_blank" class="contact_admin_button">Contact Admin</a>
            </div>
            
            </div>
            <div class="links">
                <p>Not register yet? Don't worry you can</p>
                <a href="register.php">Sign Up</a>
            </div>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                const passwordField = document.getElementById("password");
                const toggleIcon = document.getElementById("eye");

                toggleIcon.addEventListener("click", function () {
                    const type = passwordField.getAttribute("type") === "password" ? "text" : "password";
                    passwordField.setAttribute("type", type);

                    // Toggle icon classes for visibility state
                    this.classList.toggle("fa-eye");
                    this.classList.toggle("fa-eye-slash");
                });
            });
        </script>
    </div>
</body>

</html>
<?php
if (isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
?>
